"""
tools.py
Custom CrewAI-compatible tools for the Financial Document Analyzer.

Bugs fixed vs. original:
  1. `from crewai_tools import tools` — invalid import; removed.
  2. `Pdf` class was never imported; replaced with PyPDFLoader from langchain_community.
  3. `read_data_tool` was async — CrewAI tool functions must be synchronous.
  4. Missing `@tool` decorator — methods were invisible to CrewAI's tool registry.
  5. `self` parameter absent on instance methods used as static tools — converted to
     module-level functions decorated with @tool.
  6. `InvestmentTool.analyze_investment_tool` and `RiskTool.create_risk_assessment_tool`
     were stubs with async signatures and no implementation; refactored into real tools.
"""

import os
import re
import json
from typing import Optional

from crewai.tools import tool
from crewai_tools import SerperDevTool
from langchain_community.document_loaders import PyPDFLoader

from utils.logger import get_logger

logger = get_logger(__name__)

# ---------------------------------------------------------------------------
# Web search tool (SerperDevTool requires SERPER_API_KEY in env)
# ---------------------------------------------------------------------------
search_tool = SerperDevTool()


# ---------------------------------------------------------------------------
# PDF reader tool
# ---------------------------------------------------------------------------
@tool("read_financial_document")
def read_financial_document(path: str = "data/sample.pdf") -> str:
    """
    Read and extract plain text from a PDF financial document.

    Args:
        path: Filesystem path to the PDF file.

    Returns:
        Concatenated, whitespace-normalised text from every page, or an
        error message string if the file cannot be read.
    """
    if not os.path.exists(path):
        return f"ERROR: File not found at path '{path}'. Please verify the upload succeeded."

    if not path.lower().endswith(".pdf"):
        return f"ERROR: File '{path}' is not a PDF. Only PDF documents are supported."

    try:
        loader = PyPDFLoader(file_path=path)
        pages = loader.load()

        if not pages:
            return "ERROR: PDF loaded successfully but contained no extractable text."

        parts: list[str] = []
        for page in pages:
            content = page.page_content or ""
            # Collapse runs of blank lines while preserving single newlines
            content = re.sub(r"\n{3,}", "\n\n", content).strip()
            if content:
                parts.append(content)

        full_text = "\n\n".join(parts)
        logger.info("PDF loaded: %s | pages=%d | chars=%d", path, len(pages), len(full_text))
        return full_text

    except Exception as exc:  # noqa: BLE001
        logger.exception("Failed to read PDF '%s'", path)
        return f"ERROR: Could not read PDF — {exc}"


# ---------------------------------------------------------------------------
# Financial metrics extractor tool
# ---------------------------------------------------------------------------
@tool("extract_financial_metrics")
def extract_financial_metrics(document_text: str) -> str:
    """
    Parse a block of financial document text and return a JSON object
    containing key financial metrics (revenue, net income, EPS, margins, etc.).

    Args:
        document_text: Raw text extracted from a financial document.

    Returns:
        JSON string with extracted metrics, or an error string.
    """
    if not document_text or document_text.startswith("ERROR:"):
        return json.dumps({"error": "No valid document text provided."})

    # Regex patterns for common financial figures
    patterns: dict[str, str] = {
        "revenue":        r"(?:total\s+)?revenue[s]?\D{0,10}?\$?\s*([\d,]+(?:\.\d+)?)\s*(?:billion|million|B|M)?",
        "net_income":     r"net\s+income\D{0,10}?\$?\s*([\d,]+(?:\.\d+)?)\s*(?:billion|million|B|M)?",
        "eps":            r"(?:diluted\s+)?(?:EPS|earnings\s+per\s+share)\D{0,10}?\$?\s*([\d,]+(?:\.\d+)?)",
        "gross_margin":   r"gross\s+(?:profit\s+)?margin\D{0,10}?([\d,]+(?:\.\d+)?)\s*%",
        "operating_margin": r"operating\s+(?:profit\s+)?margin\D{0,10}?([\d,]+(?:\.\d+)?)\s*%",
        "free_cash_flow": r"free\s+cash\s+flow\D{0,10}?\$?\s*([\d,]+(?:\.\d+)?)\s*(?:billion|million|B|M)?",
        "debt_to_equity": r"debt[\s\-]to[\s\-]equity\D{0,10}?([\d,]+(?:\.\d+)?)",
        "current_ratio":  r"current\s+ratio\D{0,10}?([\d,]+(?:\.\d+)?)",
    }

    metrics: dict[str, Optional[str]] = {}
    lowered = document_text.lower()
    for key, pattern in patterns.items():
        match = re.search(pattern, lowered, re.IGNORECASE)
        metrics[key] = match.group(1).replace(",", "") if match else None

    metrics["extraction_note"] = (
        "Values extracted via regex heuristics. "
        "Verify against source document before use."
    )
    return json.dumps(metrics, indent=2)
