"""
config.py
Centralized, environment-driven configuration for the Financial Document Analyzer.
All secrets and tuneable parameters live here — never hardcoded in business logic.
"""

import os
from dataclasses import dataclass, field
from dotenv import load_dotenv

load_dotenv()


def _require_env(key: str) -> str:
    """Read a required environment variable or raise a clear error at startup."""
    value = os.getenv(key)
    if not value:
        raise EnvironmentError(
            f"Required environment variable '{key}' is not set. "
            f"Copy .env.example to .env and fill in your credentials."
        )
    return value


@dataclass(frozen=True)
class LLMConfig:
    """LLM provider settings."""
    model: str = field(default_factory=lambda: os.getenv("LLM_MODEL", "gpt-4o-mini"))
    temperature: float = field(default_factory=lambda: float(os.getenv("LLM_TEMPERATURE", "0.1")))
    max_tokens: int = field(default_factory=lambda: int(os.getenv("LLM_MAX_TOKENS", "4096")))


@dataclass(frozen=True)
class AgentConfig:
    """Shared agent execution limits."""
    max_iter: int = field(default_factory=lambda: int(os.getenv("AGENT_MAX_ITER", "5")))
    max_rpm: int = field(default_factory=lambda: int(os.getenv("AGENT_MAX_RPM", "10")))


@dataclass(frozen=True)
class AppConfig:
    """FastAPI / file-handling settings."""
    host: str = field(default_factory=lambda: os.getenv("APP_HOST", "0.0.0.0"))
    port: int = field(default_factory=lambda: int(os.getenv("APP_PORT", "8000")))
    data_dir: str = field(default_factory=lambda: os.getenv("DATA_DIR", "data"))
    output_dir: str = field(default_factory=lambda: os.getenv("OUTPUT_DIR", "outputs"))
    max_upload_mb: int = field(default_factory=lambda: int(os.getenv("MAX_UPLOAD_MB", "20")))


# ---------------------------------------------------------------------------
# Singleton instances consumed by the rest of the codebase
# ---------------------------------------------------------------------------
llm_cfg = LLMConfig()
agent_cfg = AgentConfig()
app_cfg = AppConfig()

# Validate critical API keys at import time so the server never starts misconfigured.
OPENAI_API_KEY: str = _require_env("OPENAI_API_KEY")
SERPER_API_KEY: str = _require_env("SERPER_API_KEY")
