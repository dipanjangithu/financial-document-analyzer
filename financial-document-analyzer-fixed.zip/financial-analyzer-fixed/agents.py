"""
agents.py
CrewAI agent definitions for the Financial Document Analyzer.

Bugs fixed vs. original:
  1. `from crewai.agents import Agent` — incorrect submodule path; changed to
     `from crewai import Agent`.
  2. `llm = llm` — self-referential assignment on an undefined name; replaced
     with a properly constructed `crewai.LLM` instance driven by config.py.
  3. `tool=[...]` (singular) — wrong keyword; CrewAI expects `tools=[...]`.
  4. `FinancialDocumentTool.read_data_tool` — referenced a class method that
     was async and lacked the @tool decorator; replaced with the fixed
     module-level `read_financial_document` tool from tools.py.
  5. Agent goals/backstories actively encouraged hallucination, regulatory
     non-compliance, and fabricating data; replaced with precise, grounded
     instructions that enforce citation, JSON output, and refusal to speculate.
  6. `verifier`, `investment_advisor`, and `risk_assessor` were defined but
     absent from the Crew; they are now used as dedicated specialists and
     wired into tasks.py accordingly.
  7. temperature=0 enforced on all agents for deterministic, reproducible output.
"""

from crewai import Agent, LLM  # BUG FIX 1 & 2

from config import llm_cfg, agent_cfg
from tools import read_financial_document, extract_financial_metrics, search_tool
from utils.logger import get_logger

logger = get_logger(__name__)

# ---------------------------------------------------------------------------
# Shared LLM instance  (BUG FIX 2 — was `llm = llm`, an undefined reference)
# ---------------------------------------------------------------------------
llm = LLM(
    model=llm_cfg.model,
    temperature=llm_cfg.temperature,   # Low temperature → deterministic output
    max_tokens=llm_cfg.max_tokens,
)

logger.info("LLM initialised: model=%s temperature=%s", llm_cfg.model, llm_cfg.temperature)

# ---------------------------------------------------------------------------
# Agent 1 — Financial Analyst (primary orchestrator)
# ---------------------------------------------------------------------------
financial_analyst = Agent(
    role="Senior Financial Analyst",
    goal=(
        "Analyse the financial document provided for the user query: {query}. "
        "Extract factual metrics, identify material trends, and produce a "
        "structured JSON summary. Do NOT speculate or fabricate data. "
        "If a figure cannot be found in the document, state 'not available'."
    ),
    backstory=(
        "You are a CFA-certified analyst with 15 years of experience evaluating "
        "corporate earnings reports, SEC filings, and investor presentations. "
        "You adhere strictly to GAAP/IFRS standards and cite specific sections "
        "of source documents for every claim. You never invent financial data."
    ),
    tools=[read_financial_document, extract_financial_metrics],  # BUG FIX 3 & 4
    llm=llm,
    verbose=True,
    memory=True,
    max_iter=agent_cfg.max_iter,
    max_rpm=agent_cfg.max_rpm,
    allow_delegation=False,
)

# ---------------------------------------------------------------------------
# Agent 2 — Document Verifier
# ---------------------------------------------------------------------------
verifier = Agent(
    role="Financial Document Verifier",
    goal=(
        "Verify that the uploaded file is a genuine financial document "
        "(annual report, 10-K, 10-Q, earnings release, or similar). "
        "Confirm the issuer name, reporting period, and document type. "
        "Return a JSON verification result with fields: "
        "is_financial_document (bool), issuer, period, document_type, confidence_score (0-1)."
    ),
    backstory=(
        "You are a former SEC examiner with deep expertise in identifying "
        "authentic financial filings. You cross-reference document structure, "
        "terminology, and metadata to confirm authenticity. You never approve "
        "a non-financial document as financial, regardless of superficial similarities."
    ),
    tools=[read_financial_document],
    llm=llm,
    verbose=True,
    memory=True,
    max_iter=agent_cfg.max_iter,
    max_rpm=agent_cfg.max_rpm,
    allow_delegation=False,
)

# ---------------------------------------------------------------------------
# Agent 3 — Investment Advisor
# ---------------------------------------------------------------------------
investment_advisor = Agent(
    role="Registered Investment Advisor",
    goal=(
        "Based solely on data extracted from the verified financial document, "
        "provide balanced, evidence-based investment considerations for the user "
        "query: {query}. Output a JSON object with fields: "
        "bull_case, bear_case, key_metrics_driving_view, suggested_due_diligence_steps, "
        "and regulatory_disclaimer. "
        "Do NOT recommend specific securities or guarantee returns."
    ),
    backstory=(
        "You are a Series-65 licensed investment advisor with institutional "
        "buy-side experience. You base every recommendation strictly on disclosed "
        "financial data, follow SEC Regulation Best Interest guidelines, and always "
        "include a disclaimer that your output is informational, not personalised "
        "investment advice. You never invent performance data."
    ),
    tools=[read_financial_document, extract_financial_metrics, search_tool],
    llm=llm,
    verbose=True,
    memory=True,
    max_iter=agent_cfg.max_iter,
    max_rpm=agent_cfg.max_rpm,
    allow_delegation=False,
)

# ---------------------------------------------------------------------------
# Agent 4 — Risk Assessor
# ---------------------------------------------------------------------------
risk_assessor = Agent(
    role="Quantitative Risk Analyst",
    goal=(
        "Identify and quantify material financial risks disclosed in the document "
        "for the user query: {query}. Output a JSON object with fields: "
        "risk_factors (list), severity (low/medium/high per factor), "
        "likelihood (low/medium/high per factor), mitigation_notes, "
        "and overall_risk_rating (1-10). "
        "Base all ratings on evidence in the document; do not fabricate scenarios."
    ),
    backstory=(
        "You are a FRM-certified risk analyst who has stress-tested portfolios "
        "at major investment banks. You apply standard frameworks (Basel III, "
        "COSO ERM) to identify liquidity, credit, market, and operational risks "
        "from financial disclosures. You never exaggerate risk for dramatic effect."
    ),
    tools=[read_financial_document, extract_financial_metrics],
    llm=llm,
    verbose=True,
    memory=True,
    max_iter=agent_cfg.max_iter,
    max_rpm=agent_cfg.max_rpm,
    allow_delegation=False,
)
