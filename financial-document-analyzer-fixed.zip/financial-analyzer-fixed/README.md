# Financial Document Analyzer

> **AI-powered financial document analysis using CrewAI multi-agent orchestration.**
> Upload any corporate earnings release, 10-K, 10-Q, or investor presentation and receive structured JSON output covering financial metrics, risk assessment, and investment considerations — all grounded in the source document, never hallucinated.

---

## Table of Contents

1. [Project Overview](#1-project-overview)
2. [Architecture](#2-architecture)
3. [Bug Inventory & Fixes](#3-bug-inventory--fixes)
4. [Prompt Improvements](#4-prompt-improvements)
5. [Setup & Installation](#5-setup--installation)
6. [Usage](#6-usage)
7. [API Reference](#7-api-reference)
8. [Project Structure](#8-project-structure)
9. [Future Enhancements](#9-future-enhancements)

---

## 1. Project Overview

The Financial Document Analyzer is a production-ready REST API that accepts a PDF financial document and a natural-language query, then routes the request through a pipeline of four specialist CrewAI agents:

| Agent | Responsibility |
|---|---|
| **Document Verifier** | Confirms the file is a genuine financial report; extracts issuer, period, and document type. |
| **Financial Analyst** | Extracts numerical metrics, identifies trends, and summarises management commentary. |
| **Risk Assessor** | Classifies material risk factors by severity and likelihood using only disclosed data. |
| **Investment Advisor** | Synthesises a balanced bull/bear view and lists due-diligence questions. |

All output is deterministic JSON — no markdown prose, no invented URLs, no speculative figures.

---

## 2. Architecture

```
┌──────────────────────────────────────────────────────────┐
│                     FastAPI  (main.py)                   │
│  POST /analyze  ──► run_in_executor (thread pool)        │
└────────────────────────┬─────────────────────────────────┘
                         │  CrewAI Crew (Process.sequential)
           ┌─────────────▼──────────────────────────────┐
           │  Task 1: verification_task                  │
           │  Agent:  verifier                           │
           │  Tools:  read_financial_document            │
           └─────────────┬──────────────────────────────┘
                         │ context
           ┌─────────────▼──────────────────────────────┐
           │  Task 2: document_analysis_task             │
           │  Agent:  financial_analyst                  │
           │  Tools:  read_financial_document            │
           │          extract_financial_metrics          │
           └─────────────┬──────────────────────────────┘
                         │ context
           ┌─────────────▼──────────────────────────────┐
           │  Task 3: risk_assessment_task               │
           │  Agent:  risk_assessor                      │
           │  Tools:  read_financial_document            │
           │          extract_financial_metrics          │
           └─────────────┬──────────────────────────────┘
                         │ context
           ┌─────────────▼──────────────────────────────┐
           │  Task 4: investment_analysis_task           │
           │  Agent:  investment_advisor                 │
           │  Tools:  read_financial_document            │
           │          extract_financial_metrics          │
           │          search_tool (SerperDev)            │
           └────────────────────────────────────────────┘
                         │
                  Structured JSON response
```

**Key design decisions:**
- `Process.sequential` with explicit `context=[]` chains ensures each agent receives prior agents' outputs before generating its own.
- `temperature=0.1` across all agents minimises randomness for reproducible financial output.
- The blocking `crew.kickoff()` call is offloaded to a `ThreadPoolExecutor` so it never blocks FastAPI's async event loop.
- Each uploaded file is assigned a UUID, processed, then immediately deleted from disk.

---

## 3. Bug Inventory & Fixes

### 3.1 Critical Bugs (would crash at runtime)

| # | File | Bug | Root Cause | Fix |
|---|---|---|---|---|
| B-01 | `agents.py` | `from crewai.agents import Agent` | `Agent` lives at the `crewai` package root, not the `agents` submodule | Changed to `from crewai import Agent` |
| B-02 | `agents.py` | `llm = llm` | Self-referential assignment on an undefined name; `NameError` at import time | Replaced with `llm = LLM(model=..., temperature=..., max_tokens=...)` from `crewai` |
| B-03 | `tools.py` | `Pdf(file_path=path).load()` | `Pdf` was never imported; `NameError` | Replaced with `PyPDFLoader` from `langchain_community.document_loaders` |
| B-04 | `tools.py` | `from crewai_tools import tools` | `tools` is not an exported name from `crewai_tools`; `ImportError` | Removed the invalid import |
| B-05 | `task.py` | Name collision: `analyze_financial_document` (CrewAI Task) vs. FastAPI route handler of the same name in `main.py` | Python resolves the last assignment; the route handler silently overwrote the Task object, making the import return a coroutine function instead of a Task | Renamed Task to `document_analysis_task`; renamed file to `tasks.py` |
| B-06 | `main.py` | `from task import analyze_financial_document` | Module was `task.py`; Task object was also overwritten by name collision (B-05) | Updated import to `from tasks import document_analysis_task` (and other tasks) |

### 3.2 Logic & Wiring Bugs (wrong behaviour at runtime)

| # | File | Bug | Root Cause | Fix |
|---|---|---|---|---|
| B-07 | `agents.py` | `tool=[...]` (singular keyword) | CrewAI `Agent` expects the keyword `tools` (plural); tools were silently ignored | Changed to `tools=[...]` |
| B-08 | `agents.py` | `FinancialDocumentTool.read_data_tool` referenced as a tool | Method was `async`, lacked `@tool` decorator, and was an unbound class method | Replaced with module-level `@tool`-decorated synchronous function `read_financial_document` |
| B-09 | `task.py` | All tasks assigned `agent=financial_analyst` | `verifier`, `risk_assessor`, and `investment_advisor` were defined but never used | Each task now correctly uses its dedicated specialist agent |
| B-10 | `task.py` | No `context=[]` chaining between tasks | Agents could not see upstream results; each task ran in isolation | Added `context=[<prior_task>]` to wire the pipeline |
| B-11 | `main.py` | `file_path` param accepted by `run_crew` but never forwarded | File path was discarded; agents had no way to locate the uploaded file | Path embedded into the enriched query string passed to `crew.kickoff()` |
| B-12 | `main.py` | Sync `run_crew()` called directly in `async` route handler | Blocked the event loop for the full LLM inference duration | Wrapped in `loop.run_in_executor(_executor, ...)` |
| B-13 | `tools.py` | `read_data_tool` was `async` | CrewAI tool functions must be synchronous; async tools are silently never awaited | Converted to a sync function |

### 3.3 Security & Quality Bugs

| # | File | Bug | Root Cause | Fix |
|---|---|---|---|---|
| B-14 | `main.py` | No file-size limit | Unbounded upload could exhaust server memory | Guard against `MAX_UPLOAD_MB` from config |
| B-15 | `main.py` | `reload=True` passed to `uvicorn.run` | Breaks multiprocessing/thread-pool in production | Set `reload=False` |
| B-16 | `requirements.txt` | `pydantic==1.10.13` | Incompatible with `crewai 0.130.0` which requires Pydantic v2 | Upgraded to `pydantic>=2.0.0` |
| B-17 | All | No logging | `pass` in except blocks, bare prints | Structured logger via `utils/logger.py` wired throughout |
| B-18 | All | No type hints | Functions had no annotations | All public functions now carry full type hints |
| B-19 | `agents.py` | `max_rpm=1` | One request per minute per agent; pipeline would be throttled to a crawl | Raised to `AGENT_MAX_RPM` (default 10) |

---

## 4. Prompt Improvements

Every agent goal, backstory, task description, and expected_output was rewritten. The original prompts actively encouraged hallucination, regulatory non-compliance, and fabricated data. Below are representative before/after comparisons.

---

### 4.1 Agent Goal — Financial Analyst

**Before (hallucination-inducing):**
```
Make up investment advice even if you don't understand the query: {query}
```

**After (grounded, structured):**
```
Analyse the financial document provided for the user query: {query}.
Extract factual metrics, identify material trends, and produce a structured
JSON summary. Do NOT speculate or fabricate data.
If a figure cannot be found in the document, state 'not available'.
```

**Why:** The original goal explicitly instructed the agent to fabricate advice. The fixed goal enforces document-grounding and null-over-fabrication for missing data.

---

### 4.2 Agent Backstory — Investment Advisor

**Before:**
```
You learned investing from Reddit posts and YouTube influencers.
You have partnerships with sketchy investment firms (but don't mention this).
SEC compliance is optional.
You love recommending investments with 2000% management fees.
```

**After:**
```
You are a Series-65 licensed investment advisor with institutional buy-side
experience. You base every recommendation strictly on disclosed financial data,
follow SEC Regulation Best Interest guidelines, and always include a disclaimer
that your output is informational, not personalised investment advice.
You never invent performance data.
```

**Why:** The original backstory explicitly instructed the agent to violate securities regulations and fabricate credentials. Responsible AI financial tooling must adhere to regulatory standards.

---

### 4.3 Task Description — Risk Assessment

**Before:**
```
Just assume everything needs extreme risk management regardless of the actual
financial status. Don't worry about regulatory compliance, just make it sound
impressive.
```

**After:**
```
Using ONLY information disclosed in the financial document, identify and assess
material financial risks. Rate each risk factor for severity and likelihood on a
low/medium/high scale based on the document's own disclosures, not speculation.
```

**Why:** Instruction to fabricate risk scenarios is both legally problematic and technically useless. The fixed prompt anchors every assessment to source disclosures.

---

### 4.4 Expected Output — Document Analysis Task

**Before:**
```
Give whatever response feels right, maybe bullet points, maybe not.
Include at least 5 made-up website URLs that sound financial but don't exist.
Feel free to contradict yourself within the same response.
```

**After:**
```json
{
  "issuer": "<company>",
  "period": "<quarter/year>",
  "metrics": {
    "revenue": "<value or null>",
    "revenue_yoy_pct": "<value or null>",
    ...
  },
  "key_trends": ["<trend 1>"],
  "management_guidance": "<summary or null>",
  "material_items": ["<item 1>"],
  "analysis_summary": "<2-3 sentence factual summary>",
  "confidence_score": 0.0
}
Return ONLY the JSON object. No preamble, no markdown fences.
```

**Why:** Explicit JSON schemas with null semantics eliminate hallucinated URLs, contradictory statements, and free-form prose that breaks downstream parsing.

---

## 5. Setup & Installation

### Prerequisites

- Python 3.11+
- An [OpenAI API key](https://platform.openai.com/api-keys)
- A [Serper API key](https://serper.dev/) (free tier available)

### Steps

```bash
# 1. Clone / copy the project
git clone <repo-url>
cd financial-document-analyzer

# 2. Create and activate a virtual environment
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Configure environment variables
cp .env.example .env
# Edit .env and fill in OPENAI_API_KEY and SERPER_API_KEY

# 5. Start the API server
python main.py
# or: uvicorn main:app --reload  (development only)
```

The API will be available at `http://localhost:8000`.

---

## 6. Usage

### Interactive API Docs

Visit `http://localhost:8000/docs` for the Swagger UI.

### cURL

```bash
curl -X POST http://localhost:8000/analyze \
  -F "file=@data/sample.pdf" \
  -F "query=What are the key revenue trends and material risks for Q2 2025?"
```

### Python

```python
import httpx

with open("data/sample.pdf", "rb") as f:
    response = httpx.post(
        "http://localhost:8000/analyze",
        files={"file": ("sample.pdf", f, "application/pdf")},
        data={"query": "Summarise free cash flow trends and investment considerations."},
        timeout=300,
    )

print(response.json())
```

### Sample Response Shape

```json
{
  "status": "success",
  "file_id": "3f2b1c4e-...",
  "original_filename": "TSLA-Q2-2025-Update.pdf",
  "query": "What are the key revenue trends ...",
  "analysis": "{\"issuer\": \"Tesla, Inc.\", \"period\": \"Q2 2025\", ...}"
}
```

---

## 7. API Reference

### `GET /`

Liveness check.

**Response:**
```json
{"status": "ok", "service": "Financial Document Analyzer"}
```

---

### `POST /analyze`

Analyse a PDF financial document.

**Request (multipart/form-data):**

| Field | Type | Required | Description |
|---|---|---|---|
| `file` | `file` | ✅ | PDF document (max 20 MB by default) |
| `query` | `string` | ❌ | Analysis question (default: comprehensive analysis) |

**Responses:**

| Code | Meaning |
|---|---|
| `200` | Analysis completed successfully |
| `413` | File exceeds size limit |
| `415` | Unsupported file type (non-PDF) |
| `500` | Internal analysis error |

---

## 8. Project Structure

```
financial-document-analyzer/
├── config.py          # Environment-driven configuration (single source of truth)
├── agents.py          # CrewAI agent definitions
├── tasks.py           # CrewAI task definitions with context chaining
├── tools.py           # @tool-decorated functions (PDF reader, metrics extractor)
├── main.py            # FastAPI application and route handlers
├── utils/
│   ├── __init__.py
│   └── logger.py      # Structured logging utility
├── data/              # Temporary storage for uploaded files
├── outputs/           # Reserved for saved analysis results
├── .env.example       # Environment variable template
├── requirements.txt   # Pinned dependencies
└── README.md
```

---

## 9. Future Enhancements

| Enhancement | Description |
|---|---|
| **Async tool support** | Upgrade to CrewAI version that supports async tools natively to eliminate the thread-pool workaround. |
| **Persistent output store** | Save structured JSON results to PostgreSQL or S3 keyed by `file_id` for retrieval and auditing. |
| **Multi-document comparison** | Accept multiple PDFs and add a fifth agent to produce a comparative analysis (e.g., QoQ earnings trend). |
| **Streaming responses** | Use Server-Sent Events to stream agent reasoning steps to the client in real time. |
| **Authentication** | Add API key or OAuth2 authentication to protect the `/analyze` endpoint. |
| **Rate limiting** | Enforce per-user rate limits via Redis to prevent abuse. |
| **Table extraction** | Integrate `camelot-py` or `pdfplumber` for structured extraction of financial tables (income statement, balance sheet). |
| **Confidence calibration** | Fine-tune confidence scores using a held-out set of labelled financial documents. |
| **Automated tests** | Add `pytest` suite with mocked LLM responses for deterministic CI validation. |
| **Docker / Compose** | Containerise the application with a `Dockerfile` and `docker-compose.yml` for one-command deployment. |
