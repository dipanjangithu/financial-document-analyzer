"""
tasks.py  (renamed from task.py for clarity)
CrewAI task definitions for the Financial Document Analyzer.

Bugs fixed vs. original:
  1. File was named task.py but imported as `task` — renamed to tasks.py for
     clarity; main.py import updated accordingly.
  2. `analyze_financial_document` task name collided with the FastAPI endpoint
     of the same name in main.py, causing a silent override of the route
     handler; renamed to `document_analysis_task`.
  3. `from agents import financial_analyst, verifier` — `verifier` was imported
     but tasks were incorrectly all assigned to `financial_analyst`; each task
     is now assigned to the correct specialist agent.
  4. Task descriptions actively instructed agents to hallucinate, fabricate
     URLs, and contradict themselves; replaced with strict, structured prompts.
  5. `expected_output` fields requested bullet-point hallucinations with fake
     URLs; replaced with explicit JSON schemas so output is machine-readable
     and deterministic.
  6. All tasks had `async_execution=False` but there was no context chaining
     between dependent tasks; `context` fields now wire the pipeline correctly.
"""

from crewai import Task

from agents import financial_analyst, verifier, investment_advisor, risk_assessor
from tools import read_financial_document, extract_financial_metrics

# ---------------------------------------------------------------------------
# Task 1 — Document Verification  (BUG FIX 3: was incorrectly agent=financial_analyst)
# ---------------------------------------------------------------------------
verification_task = Task(
    description=(
        "Verify the uploaded financial document located at the path provided "
        "in the user query context.\n\n"
        "Steps:\n"
        "1. Use the read_financial_document tool to load the file.\n"
        "2. Confirm the document is a genuine financial report (10-K, 10-Q, "
        "   earnings release, annual report, or equivalent).\n"
        "3. Extract: issuer name, reporting period, document type.\n"
        "4. Assign a confidence score (0.0–1.0) for the classification.\n\n"
        "If the document is NOT a financial report, set is_financial_document=false "
        "and stop — do not proceed with further analysis.\n\n"
        "User query: {query}"
    ),
    expected_output=(
        "A JSON object with exactly these fields:\n"
        "{\n"
        '  "is_financial_document": true,\n'
        '  "issuer": "<company name>",\n'
        '  "period": "<e.g. Q2 2025>",\n'
        '  "document_type": "<e.g. Earnings Release>",\n'
        '  "confidence_score": 0.97,\n'
        '  "verification_notes": "<brief factual note>"\n'
        "}\n"
        "Return ONLY the JSON object. No preamble, no markdown fences."
    ),
    agent=verifier,  # BUG FIX 3
    tools=[read_financial_document],
    async_execution=False,
)

# ---------------------------------------------------------------------------
# Task 2 — Core Financial Analysis  (BUG FIX 2: renamed from analyze_financial_document)
# ---------------------------------------------------------------------------
document_analysis_task = Task(
    description=(
        "Perform a comprehensive financial analysis of the verified document.\n\n"
        "Steps:\n"
        "1. Use read_financial_document to load the full document text.\n"
        "2. Use extract_financial_metrics to pull key numerical metrics.\n"
        "3. Identify year-over-year or quarter-over-quarter trends.\n"
        "4. Highlight any forward guidance or management commentary.\n"
        "5. Note any material accounting changes or one-time items.\n\n"
        "All figures must be cited with the section of the document they appear in. "
        "If a figure is absent, record it as null — never estimate.\n\n"
        "User query: {query}"
    ),
    expected_output=(
        "A JSON object with exactly these fields:\n"
        "{\n"
        '  "issuer": "<company>",\n'
        '  "period": "<quarter/year>",\n'
        '  "metrics": {\n'
        '    "revenue": "<value or null>",\n'
        '    "revenue_yoy_pct": "<value or null>",\n'
        '    "net_income": "<value or null>",\n'
        '    "eps_diluted": "<value or null>",\n'
        '    "gross_margin_pct": "<value or null>",\n'
        '    "operating_margin_pct": "<value or null>",\n'
        '    "free_cash_flow": "<value or null>"\n'
        "  },\n"
        '  "key_trends": ["<trend 1>", "<trend 2>"],\n'
        '  "management_guidance": "<summary or null>",\n'
        '  "material_items": ["<item 1>"],\n'
        '  "analysis_summary": "<2-3 sentence factual summary>",\n'
        '  "confidence_score": 0.0\n'
        "}\n"
        "Return ONLY the JSON object. No preamble, no markdown fences."
    ),
    agent=financial_analyst,
    tools=[read_financial_document, extract_financial_metrics],
    context=[verification_task],   # BUG FIX 6: depends on verified document
    async_execution=False,
)

# ---------------------------------------------------------------------------
# Task 3 — Risk Assessment  (BUG FIX 3: was incorrectly agent=financial_analyst)
# ---------------------------------------------------------------------------
risk_assessment_task = Task(
    description=(
        "Using ONLY information disclosed in the financial document, identify and "
        "assess material financial risks.\n\n"
        "Categories to evaluate (where data is available):\n"
        "- Market risk (interest rate, FX, commodity exposure)\n"
        "- Liquidity risk (cash runway, debt maturity profile)\n"
        "- Credit risk (counterparty concentration, receivables quality)\n"
        "- Operational risk (supply chain, regulatory, litigation)\n"
        "- Macroeconomic risk (cited in management commentary)\n\n"
        "Rate each risk factor for severity and likelihood on a low/medium/high scale "
        "based on the document's own disclosures, not speculation.\n\n"
        "User query: {query}"
    ),
    expected_output=(
        "A JSON object with exactly these fields:\n"
        "{\n"
        '  "risk_factors": [\n'
        '    {\n'
        '      "name": "<risk name>",\n'
        '      "description": "<one sentence from document>",\n'
        '      "severity": "low|medium|high",\n'
        '      "likelihood": "low|medium|high",\n'
        '      "source_section": "<document section>"\n'
        "    }\n"
        "  ],\n"
        '  "mitigation_notes": "<management-stated mitigations or null>",\n'
        '  "overall_risk_rating": 5,\n'
        '  "rating_rationale": "<one sentence>"\n'
        "}\n"
        "overall_risk_rating must be an integer 1–10 (10 = highest risk). "
        "Return ONLY the JSON object. No preamble, no markdown fences."
    ),
    agent=risk_assessor,  # BUG FIX 3
    tools=[read_financial_document, extract_financial_metrics],
    context=[document_analysis_task],  # BUG FIX 6
    async_execution=False,
)

# ---------------------------------------------------------------------------
# Task 4 — Investment Considerations  (BUG FIX 3: was incorrectly agent=financial_analyst)
# ---------------------------------------------------------------------------
investment_analysis_task = Task(
    description=(
        "Based on the financial analysis and risk assessment already completed, "
        "synthesise balanced, evidence-based investment considerations.\n\n"
        "Requirements:\n"
        "- Ground every point in a specific metric or disclosure from the document.\n"
        "- Present both bull and bear perspectives objectively.\n"
        "- List concrete due-diligence questions an investor should research further.\n"
        "- Do NOT recommend specific securities, predict price targets, or guarantee returns.\n"
        "- Include the mandatory regulatory disclaimer.\n\n"
        "User query: {query}"
    ),
    expected_output=(
        "A JSON object with exactly these fields:\n"
        "{\n"
        '  "bull_case": ["<point grounded in document data>"],\n'
        '  "bear_case": ["<point grounded in document data>"],\n'
        '  "key_metrics_driving_view": {\n'
        '    "<metric name>": "<value and significance>"\n'
        "  },\n"
        '  "due_diligence_questions": ["<question 1>", "<question 2>"],\n'
        '  "overall_sentiment": "positive|neutral|negative|mixed",\n'
        '  "confidence_score": 0.0,\n'
        '  "regulatory_disclaimer": "This output is for informational purposes only '
        'and does not constitute personalised investment advice. Consult a qualified '
        'financial professional before making investment decisions."\n'
        "}\n"
        "Return ONLY the JSON object. No preamble, no markdown fences."
    ),
    agent=investment_advisor,  # BUG FIX 3
    tools=[read_financial_document, extract_financial_metrics, ],
    context=[document_analysis_task, risk_assessment_task],  # BUG FIX 6
    async_execution=False,
)
