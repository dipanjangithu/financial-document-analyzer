"""
main.py
FastAPI application entry point for the Financial Document Analyzer.

Bugs fixed vs. original:
  1. `from task import analyze_financial_document` — task.py was renamed to
     tasks.py; import updated to `from tasks import document_analysis_task`
     (and other tasks).
  2. Name collision: the FastAPI route handler was also named
     `analyze_financial_document`, silently shadowing the imported CrewAI Task
     object. Route handler renamed to `analyze_document_endpoint`.
  3. `run_crew` was a synchronous function called directly inside an async
     route handler, blocking the event loop. Fixed with
     `asyncio.get_event_loop().run_in_executor(None, ...)` to offload the
     blocking CrewAI work to a thread pool.
  4. `file_path` parameter was accepted by `run_crew` but never forwarded to
     the Crew or tasks; the query now embeds the file path so agents can
     locate the uploaded file.
  5. No file-size validation — large files could exhaust memory; guard added.
  6. Cleanup on success path was missing (finally block only ran on exception
     in some Python versions); `finally` block confirmed to cover all paths.
  7. No structured logging; replaced bare print/pass with proper logger calls.
"""

import os
import uuid
import asyncio
from concurrent.futures import ThreadPoolExecutor
from contextlib import asynccontextmanager
from typing import Any

from fastapi import FastAPI, File, UploadFile, Form, HTTPException
from fastapi.responses import JSONResponse

from crewai import Crew, Process

from config import app_cfg
from agents import financial_analyst, verifier, investment_advisor, risk_assessor
from tasks import (          # BUG FIX 1 & 2 — correct module name & no name collision
    verification_task,
    document_analysis_task,
    risk_assessment_task,
    investment_analysis_task,
)
from utils.logger import get_logger

logger = get_logger(__name__)

# Thread pool used to run blocking CrewAI work off the async event loop (BUG FIX 3)
_executor = ThreadPoolExecutor(max_workers=4)


# ---------------------------------------------------------------------------
# Application lifecycle
# ---------------------------------------------------------------------------
@asynccontextmanager
async def lifespan(_app: FastAPI):
    os.makedirs(app_cfg.data_dir, exist_ok=True)
    os.makedirs(app_cfg.output_dir, exist_ok=True)
    logger.info("Financial Document Analyzer starting up.")
    yield
    _executor.shutdown(wait=False)
    logger.info("Financial Document Analyzer shut down.")


app = FastAPI(
    title="Financial Document Analyzer",
    description="AI-powered financial document analysis using CrewAI agents.",
    version="1.0.0",
    lifespan=lifespan,
)


# ---------------------------------------------------------------------------
# Crew factory — builds a fresh Crew per request to avoid state leakage
# ---------------------------------------------------------------------------
def _build_crew() -> Crew:
    return Crew(
        agents=[verifier, financial_analyst, risk_assessor, investment_advisor],
        tasks=[
            verification_task,
            document_analysis_task,
            risk_assessment_task,
            investment_analysis_task,
        ],
        process=Process.sequential,
        verbose=True,
    )


def _run_crew_sync(query: str, file_path: str) -> Any:
    """
    Synchronous wrapper executed in a thread pool (BUG FIX 3).
    Embeds file_path in the query so every agent/tool can locate the file
    (BUG FIX 4 — file_path was previously ignored).
    """
    enriched_query = f"{query}\n\n[Document path for tool use: {file_path}]"
    crew = _build_crew()
    return crew.kickoff({"query": enriched_query})


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------
@app.get("/", tags=["Health"])
async def root():
    """Liveness check."""
    return {"status": "ok", "service": "Financial Document Analyzer"}


@app.post("/analyze", tags=["Analysis"])  # BUG FIX 2 — route handler renamed
async def analyze_document_endpoint(
    file: UploadFile = File(..., description="PDF financial document to analyse."),
    query: str = Form(
        default="Provide a comprehensive financial analysis including key metrics, "
                "risk assessment, and investment considerations.",
        description="Natural-language analysis request.",
    ),
) -> JSONResponse:
    """
    Upload a PDF financial document and receive a structured AI-powered analysis.

    The pipeline runs four specialist agents in sequence:
      1. Document Verifier  → confirms the file is a financial report
      2. Financial Analyst  → extracts metrics and identifies trends
      3. Risk Assessor      → rates material risk factors
      4. Investment Advisor → synthesises balanced investment considerations
    """
    # --- Validate file type -------------------------------------------------
    if file.content_type not in ("application/pdf", "application/octet-stream"):
        raise HTTPException(
            status_code=415,
            detail=f"Unsupported file type '{file.content_type}'. Only PDF is accepted.",
        )

    # --- Validate file size (BUG FIX 5) ------------------------------------
    content = await file.read()
    max_bytes = app_cfg.max_upload_mb * 1024 * 1024
    if len(content) > max_bytes:
        raise HTTPException(
            status_code=413,
            detail=f"File exceeds the {app_cfg.max_upload_mb} MB limit.",
        )

    # --- Persist upload to disk --------------------------------------------
    file_id = str(uuid.uuid4())
    file_path = os.path.join(app_cfg.data_dir, f"upload_{file_id}.pdf")

    try:
        with open(file_path, "wb") as fh:
            fh.write(content)
        logger.info("Saved upload: %s (%d bytes)", file_path, len(content))

        # Sanitise query
        query = query.strip() or (
            "Provide a comprehensive financial analysis including key metrics, "
            "risk assessment, and investment considerations."
        )

        # --- Run CrewAI in thread pool (BUG FIX 3) -------------------------
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(
            _executor,
            _run_crew_sync,
            query,
            file_path,
        )

        logger.info("Analysis complete for upload %s", file_id)

        return JSONResponse(
            status_code=200,
            content={
                "status": "success",
                "file_id": file_id,
                "original_filename": file.filename,
                "query": query,
                "analysis": str(result),
            },
        )

    except HTTPException:
        raise
    except Exception as exc:  # noqa: BLE001
        logger.exception("Error processing upload %s", file_id)
        raise HTTPException(
            status_code=500,
            detail=f"Analysis failed: {exc}",
        ) from exc

    finally:  # BUG FIX 6 — cleanup guaranteed on every path
        if os.path.exists(file_path):
            try:
                os.remove(file_path)
                logger.debug("Cleaned up temp file: %s", file_path)
            except OSError:
                logger.warning("Could not remove temp file: %s", file_path)


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "main:app",
        host=app_cfg.host,
        port=app_cfg.port,
        reload=False,   # Never use reload=True in production (breaks multiprocessing)
        log_level="info",
    )
